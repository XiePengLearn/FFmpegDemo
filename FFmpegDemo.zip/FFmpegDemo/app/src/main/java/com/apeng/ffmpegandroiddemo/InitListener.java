package com.apeng.ffmpegandroiddemo;

public interface InitListener {
    public void onLoadSuccess();
    public void onLoadFail(String reason);
}
