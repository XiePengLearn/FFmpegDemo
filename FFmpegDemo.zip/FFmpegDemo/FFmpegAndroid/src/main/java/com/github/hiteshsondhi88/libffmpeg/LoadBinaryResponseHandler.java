package com.github.hiteshsondhi88.libffmpeg;

public class LoadBinaryResponseHandler implements FFmpegLoadBinaryResponseHandler {

    @Override
    public void onFailure() {

    }

    @Override
    public void onSuccess() {

    }

    @Override
    public void onStart() {

    }

    @Override
    public void onFinish() {

    }
}
