package com.github.hiteshsondhi88.libffmpeg.exceptions;

public class FFmpegNotSupportedException extends Exception {

    public FFmpegNotSupportedException(String message) {
        super(message);
    }

}
